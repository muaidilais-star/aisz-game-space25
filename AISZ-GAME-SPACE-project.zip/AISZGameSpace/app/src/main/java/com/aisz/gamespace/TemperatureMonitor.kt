package com.aisz.gamespace

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import java.util.Locale

enum class TempLevel(val label: String) {
    NORMAL("Normal"),
    WARM("Hangat"),
    HIGH("Tinggi"),
    UNKNOWN("N/A")
}

data class ThermalReading(
    val batteryC: Float?,
    val level: TempLevel,
    val thermalStatus: String?
)

fun formatCelsius(value: Float?): String =
    if (value == null) "N/A" else String.format(Locale.US, "%.1f °C", value)

/** Membaca suhu baterai + status termal resmi (Android 10+). Tidak ada data karangan. */
class TemperatureMonitor(private val context: Context) {

    fun read(): ThermalReading {
        val battery = batteryTempC()
        val severity = thermalSeverity()
        val level = when {
            battery == null && severity == null -> TempLevel.UNKNOWN
            (battery != null && battery >= 42f) || (severity != null && severity >= 2) -> TempLevel.HIGH
            (battery != null && battery >= 38f) || (severity != null && severity == 1) -> TempLevel.WARM
            else -> TempLevel.NORMAL
        }
        return ThermalReading(battery, level, severity?.let { statusLabel(it) })
    }

    private fun batteryTempC(): Float? {
        val i: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val raw = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        return if (raw == Int.MIN_VALUE) null else raw / 10f
    }

    private fun thermalSeverity(): Int? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.currentThermalStatus
        } catch (e: Exception) {
            null
        }
    }

    private fun statusLabel(s: Int): String = when (s) {
        0 -> "Tidak ada pembatasan"
        1 -> "Ringan"
        2 -> "Sedang"
        3 -> "Berat"
        4 -> "Kritis"
        5 -> "Darurat"
        6 -> "Mati darurat"
        else -> "N/A"
    }
}
