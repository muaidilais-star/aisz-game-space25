package com.aisz.gamespace

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aisz.gamespace.ui.AiszColors
import com.aisz.gamespace.ui.NeonButton
import kotlin.math.roundToInt

data class TouchPoint(val id: Long, val x: Float, val y: Float)

/** Area uji layar sentuh: multi-touch, koordinat, jejak, dan tombol reset. */
@Composable
fun TouchTesterScreen() {
    var active by remember { mutableStateOf<List<TouchPoint>>(emptyList()) }
    var trail by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var maxPointers by remember { mutableStateOf(0) }
    val shape = RoundedCornerShape(20.dp)

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Touch Tester", color = AiszColors.Neon, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Aktif: ${active.size}  •  Maks multi-touch: $maxPointers",
                    color = AiszColors.TextDim, fontSize = 13.sp
                )
            }
            NeonButton("Reset") {
                active = emptyList()
                trail = emptyList()
                maxPointers = 0
            }
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(top = 12.dp)
                .clip(shape)
                .background(AiszColors.Surface)
                .border(1.dp, AiszColors.Neon.copy(alpha = 0.5f), shape)
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent()
                            val down = event.changes.filter { it.pressed }
                            active = down.map { TouchPoint(it.id.value, it.position.x, it.position.y) }
                            if (down.size > maxPointers) maxPointers = down.size
                            if (down.isNotEmpty()) {
                                trail = (trail + down.map { it.position }).takeLast(500)
                            }
                            event.changes.forEach { it.consume() }
                        }
                    }
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val grid = 64.dp.toPx()
                var gx = grid
                while (gx < size.width) {
                    drawLine(AiszColors.Neon.copy(alpha = 0.07f), Offset(gx, 0f), Offset(gx, size.height), 1f)
                    gx += grid
                }
                var gy = grid
                while (gy < size.height) {
                    drawLine(AiszColors.Neon.copy(alpha = 0.07f), Offset(0f, gy), Offset(size.width, gy), 1f)
                    gy += grid
                }
                trail.forEachIndexed { i, pt ->
                    val fade = (i + 1) / trail.size.toFloat()
                    drawCircle(AiszColors.Neon.copy(alpha = 0.08f + 0.3f * fade), (3f + 4f * fade).dp.toPx(), pt)
                }
                active.forEach { p ->
                    val c = Offset(p.x, p.y)
                    drawLine(AiszColors.NeonSoft.copy(alpha = 0.6f), Offset(c.x, 0f), Offset(c.x, size.height), 1.5f)
                    drawLine(AiszColors.NeonSoft.copy(alpha = 0.6f), Offset(0f, c.y), Offset(size.width, c.y), 1.5f)
                    drawCircle(AiszColors.Neon.copy(alpha = 0.25f), 38.dp.toPx(), c)
                    drawCircle(AiszColors.Neon, 16.dp.toPx(), c)
                }
            }
            Column(Modifier.padding(12.dp)) {
                if (active.isEmpty()) {
                    Text("Sentuh area ini dengan satu atau beberapa jari.", color = AiszColors.TextDim, fontSize = 13.sp)
                } else {
                    active.forEachIndexed { i, p ->
                        Text(
                            "Jari ${i + 1}:  x = ${p.x.roundToInt()}   y = ${p.y.roundToInt()}",
                            color = AiszColors.Text, fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}
