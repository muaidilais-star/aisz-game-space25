package com.aisz.gamespace

import android.view.Choreographer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.roundToInt

/**
 * Mengukur frame rate render jendela AISZ sendiri lewat Choreographer (API resmi).
 * Android tanpa root TIDAK menyediakan API untuk membaca FPS aplikasi/game lain,
 * sehingga FPS game selalu ditampilkan sebagai N/A.
 */
class FpsMonitor {
    var fps: Int? by mutableStateOf(null)
        private set

    private var running = false
    private var frames = 0
    private var windowStartNs = 0L

    private val callback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            if (windowStartNs == 0L) windowStartNs = frameTimeNanos
            frames++
            val elapsed = frameTimeNanos - windowStartNs
            if (elapsed >= 1_000_000_000L) {
                fps = (frames * 1_000_000_000.0 / elapsed).roundToInt()
                frames = 0
                windowStartNs = frameTimeNanos
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun start() {
        if (running) return
        running = true
        frames = 0
        windowStartNs = 0L
        Choreographer.getInstance().postFrameCallback(callback)
    }

    fun stop() {
        running = false
        Choreographer.getInstance().removeFrameCallback(callback)
    }
}
