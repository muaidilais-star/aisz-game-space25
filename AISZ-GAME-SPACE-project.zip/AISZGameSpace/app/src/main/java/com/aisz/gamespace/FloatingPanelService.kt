package com.aisz.gamespace

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.Spannable
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max

/** Grafik garis kecil untuk riwayat latensi. */
class MiniGraph(context: Context) : View(context) {
    private var values: List<Float> = emptyList()
    private var color: Int = Color.parseColor("#00B7FF")
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 2.5f * resources.displayMetrics.density
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    fun setValues(v: List<Float>, c: Int) {
        values = v
        color = c
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (values.size < 2) return
        val w = width.toFloat()
        val h = height.toFloat()
        val top = max(100f, values.max())
        val step = w / (values.size - 1)
        val lp = Path()
        val fp = Path()
        values.forEachIndexed { i, v ->
            val x = i * step
            val y = h - (v / top).coerceIn(0f, 1f) * h * 0.9f
            if (i == 0) {
                lp.moveTo(x, y)
                fp.moveTo(x, h)
                fp.lineTo(x, y)
            } else {
                lp.lineTo(x, y)
                fp.lineTo(x, y)
            }
        }
        fp.lineTo(w, h)
        fp.close()
        fill.shader = LinearGradient(
            0f, 0f, 0f, h,
            Color.argb(90, Color.red(color), Color.green(color), Color.blue(color)),
            Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        line.color = color
        canvas.drawPath(fp, fill)
        canvas.drawPath(lp, line)
    }
}

/**
 * Panel gaming melayang: handle tipis di tepi layar. Ketuk = buka/tutup, seret = pindah.
 * Isi: dock aplikasi jendela mengambang, status WLAN/FPS/suhu/latensi, mode performa,
 * kecerahan, dan tombol cepat (rekam layar, mulai cepat, frame tinggi, Jangan Ganggu).
 */
class FloatingPanelService : Service() {

    private class Tile(val view: LinearLayout, val sub: TextView, val dot: View)

    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private var root: LinearLayout? = null
    private lateinit var handle: FrameLayout
    private lateinit var handleBar: View
    private lateinit var panel: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var tvNet: TextView
    private lateinit var tvFps: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvPing: TextView
    private lateinit var graph: MiniGraph
    private lateinit var seekBright: SeekBar
    private lateinit var tvFooter: TextView
    private lateinit var gamesBox: LinearLayout
    private lateinit var tileRec: Tile
    private lateinit var tileFrame: Tile
    private lateinit var tileDnd: Tile
    private val modeButtons = mutableMapOf<GamingProfile, TextView>()

    private var expanded = false
    private var dockRight = false
    private var blink = false
    private val pingHistory = ArrayList<Float>()
    @Volatile private var gamePkg: String? = null
    private var homePkg: String? = null
    private var warnedBrightness = false

    private val handler = Handler(Looper.getMainLooper())
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 2000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izin tampil di atas aplikasi lain belum diberikan.", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        if (root == null) buildOverlay()
        isRunning = true
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        executor.shutdownNow()
        root?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        root = null
        isRunning = false
        super.onDestroy()
    }

    // ------------------------------------------------------------ notifikasi

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Panel gaming", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingPanelService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_aisz)
            .setContentTitle("AISZ GAME SPACE")
            .setContentText("Panel gaming aktif")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(open)
            .addAction(0, "Tutup panel", stop)
            .build()
    }

    private fun startAsForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ------------------------------------------------------------ helper tampilan

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, radius: Float, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = radius
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun circle(fill: Int, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fill)
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    @SuppressLint("ClickableViewAccessibility")
    private fun View.pressable(onClick: () -> Unit) {
        setOnClickListener { onClick() }
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
    }

    private fun smallButton(label: String, onClick: () -> Unit): TextView =
        text(label, 12f, TEXT).apply {
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(9), dp(6), dp(9))
            background = rounded(CARD, dp(12).toFloat(), STROKE)
            pressable(onClick)
        }

    private fun rowOf(vararg views: View): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            views.forEach {
                addView(it, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                })
            }
        }

    private fun makeTile(title: String, sub: String, onClick: () -> Unit): Tile {
        val dot = View(this).apply { background = circle(DIM) }
        val t = text(title, 12f, TEXT, true)
        val s = text(sub, 10f, DIM)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(t)
            addView(s)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rounded(CARD, dp(14).toFloat(), STROKE)
            addView(dot, lp(dp(8), dp(8)).apply { rightMargin = dp(8) })
            addView(col)
            pressable(onClick)
        }
        return Tile(box, s, dot)
    }

    // ------------------------------------------------------------ susunan panel

    private fun buildHeader(): LinearLayout {
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(CARD, dp(16).toFloat(), STROKE)
        }
        tvNet = text("WLAN", 11f, DIM)
        tvFps = text("N/A FPS", 12f, TEXT, true)
        tvTemp = text("-- °C", 12f, TEXT, true).apply { setPadding(dp(10), 0, 0, 0) }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(tvNet, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(tvFps)
            addView(tvTemp)
        }
        h.addView(top)

        graph = MiniGraph(this)
        tvPing = text("--", 30f, NEON, true)
        val frame = FrameLayout(this).apply {
            addView(graph, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(tvPing, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.START or Gravity.CENTER_VERTICAL
            ))
        }
        h.addView(frame, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(64)).apply {
            topMargin = dp(4)
            bottomMargin = dp(6)
        })

        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        GamingProfile.values().forEach { p ->
            val b = text(p.label, 12f, DIM).apply {
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(8), dp(4), dp(8))
                pressable { selectMode(p) }
            }
            modeButtons[p] = b
            modes.addView(b, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        h.addView(modes)
        return h
    }

    private fun buildBrightness(): LinearLayout {
        seekBright = SeekBar(this).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(NEON)
            thumbTintList = ColorStateList.valueOf(NEON)
            progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#26334D"))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) applyBrightness(progress.coerceAtLeast(1))
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = rounded(CARD, dp(14).toFloat(), STROKE)
            addView(text("Cerah", 11f, DIM))
            addView(seekBright, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
    }

    private fun buildPanel(): LinearLayout {
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }
        val title = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(text("AISZ", 15f, NEON, true))
            addView(text("  GAME SPACE", 10f, DIM))
        }
        content.addView(title, lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) })
        content.addView(buildHeader(), lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) })
        content.addView(buildBrightness(), lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(3) })

        tileRec = makeTile("Rekam layar", "Siap") { toggleRecord() }
        val tileQuick = makeTile("Mulai cepat", "Performa + game favorit") { quickStart() }
        tileFrame = makeTile("Frame tinggi", "Normal") { toggleFrameLock() }
        tileDnd = makeTile("Jangan ganggu", "Mati") { toggleDnd() }
        content.addView(rowOf(tileRec.view, tileQuick.view))
        content.addView(rowOf(tileFrame.view, tileDnd.view))

        content.addView(rowOf(
            smallButton("Vol -") { adjustVolume(AudioManager.ADJUST_LOWER) },
            smallButton("Vol +") { adjustVolume(AudioManager.ADJUST_RAISE) },
            smallButton("Senyap") { adjustVolume(AudioManager.ADJUST_TOGGLE_MUTE) }
        ))

        content.addView(text("Game favorit", 11f, DIM).apply { setPadding(dp(4), dp(6), 0, dp(2)) })
        gamesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(gamesBox)

        content.addView(rowOf(
            smallButton("Buka AISZ") { openApp() },
            smallButton("Tutup panel") { stopSelf() }
        ))
        tvFooter = text("Shizuku: -", 10f, DIM).apply {
            setPadding(dp(4), dp(4), 0, 0)
            pressable { openApp() }
        }
        content.addView(tvFooter)

        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(content)
        }
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = rounded(PANEL_BG, dp(22).toFloat(), NEON)
            addView(dock, lp(dp(46), LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) })
            addView(scroll, lp(cardWidth(), LinearLayout.LayoutParams.WRAP_CONTENT))
        }
    }

    private fun cardWidth(): Int =
        minOf(dp(270), resources.displayMetrics.widthPixels - dp(120))

    private fun rebuildDock() {
        dock.removeAllViews()
        GameSettings(this).dockApps.take(4).forEach { pkg ->
            val icon = try {
                packageManager.getApplicationIcon(pkg)
            } catch (e: Exception) {
                null
            } ?: return@forEach
            val iv = ImageView(this).apply {
                setImageDrawable(icon)
                background = circle(CARD, STROKE)
                setPadding(dp(5), dp(5), dp(5), dp(5))
                outlineProvider = ViewOutlineProvider.BACKGROUND
                clipToOutline = true
                pressable { openFloating(pkg) }
            }
            dock.addView(iv, lp(dp(42), dp(42)).apply { setMargins(0, dp(3), 0, dp(3)) })
        }
        val plus = text("+", 20f, NEON, true).apply {
            gravity = Gravity.CENTER
            background = circle(CARD, STROKE)
            pressable { openApp() }
        }
        dock.addView(plus, lp(dp(42), dp(42)).apply { setMargins(0, dp(3), 0, dp(3)) })
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildOverlay() {
        homePkg = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        )?.activityInfo?.packageName

        handleBar = View(this).apply { background = rounded(NEON, dp(3).toFloat()) }
        handle = FrameLayout(this).apply {
            addView(handleBar, FrameLayout.LayoutParams(dp(6), dp(72), Gravity.CENTER))
            setOnTouchListener(dragListener)
        }
        panel = buildPanel()
        panel.visibility = View.GONE

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        root = container
        arrangeChildren()

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = resources.displayMetrics.heightPixels / 3
        }
        wm.addView(container, params)
        syncModeButtons()
    }

    private fun arrangeChildren() {
        val r = root ?: return
        r.removeAllViews()
        val handleLp = lp(dp(22), dp(96))
        val panelLp = lp(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        if (dockRight) {
            r.addView(panel, panelLp)
            r.addView(handle, handleLp)
        } else {
            r.addView(handle, handleLp)
            r.addView(panel, panelLp)
        }
    }

    private fun updateLayout() {
        val r = root ?: return
        val dm = resources.displayMetrics
        params.x = params.x.coerceIn(0, max(0, dm.widthPixels - r.width))
        params.y = params.y.coerceIn(0, max(0, dm.heightPixels - r.height))
        try {
            wm.updateViewLayout(r, params)
        } catch (_: Exception) {
        }
    }

    private fun stickToEdge() {
        val r = root ?: return
        params.x = if (dockRight) resources.displayMetrics.widthPixels - r.width else 0
        updateLayout()
    }

    private fun limitPanelHeight() {
        val w = cardWidth()
        content.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val limit = resources.displayMetrics.heightPixels - dp(56)
        val lpScroll = scroll.layoutParams
        lpScroll.width = w
        lpScroll.height = minOf(content.measuredHeight, limit)
        scroll.layoutParams = lpScroll
    }

    private fun slideOffset(): Float = if (dockRight) dp(24).toFloat() else -dp(24).toFloat()

    private fun toggle() {
        expanded = !expanded
        if (expanded) {
            rebuildDock()
            refreshFavorites()
            syncModeButtons()
            syncTiles()
            seekBright.progress = GameSettings(this).getBrightnessPercent()
            warnedBrightness = false
            limitPanelHeight()
            panel.visibility = View.VISIBLE
            panel.alpha = 0f
            panel.translationX = slideOffset()
            panel.animate().alpha(1f).translationX(0f).setDuration(220).start()
            tick()
        } else {
            panel.animate().alpha(0f).translationX(slideOffset()).setDuration(160).withEndAction {
                panel.visibility = View.GONE
                root?.post { stickToEdge() }
            }.start()
        }
        root?.post { stickToEdge() }
    }

    private val dragListener = object : View.OnTouchListener {
        private var startRawX = 0f
        private var startRawY = 0f
        private var startX = 0
        private var startY = 0
        private var dragging = false
        private val slop by lazy { ViewConfiguration.get(this@FloatingPanelService).scaledTouchSlop }

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = e.rawX
                    startRawY = e.rawY
                    startX = params.x
                    startY = params.y
                    dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startRawX
                    val dy = e.rawY - startRawY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                    if (dragging) {
                        params.x = (startX + dx).toInt()
                        params.y = (startY + dy).toInt()
                        updateLayout()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) {
                        val r = root
                        if (r != null) {
                            val right = params.x + r.width / 2 > resources.displayMetrics.widthPixels / 2
                            if (right != dockRight) {
                                dockRight = right
                                arrangeChildren()
                            }
                            r.post { stickToEdge() }
                        }
                    } else {
                        v.performClick()
                        toggle()
                    }
                }
            }
            return true
        }
    }

    // ------------------------------------------------------------ data berkala

    private fun levelColor(level: TempLevel): Int = when (level) {
        TempLevel.NORMAL -> OK
        TempLevel.WARM -> WARN
        TempLevel.HIGH -> HOT
        TempLevel.UNKNOWN -> DIM
    }

    private fun setPing(ms: Int?) {
        val s = if (ms == null) "-- ms" else "$ms ms"
        val sp = SpannableString(s)
        sp.setSpan(RelativeSizeSpan(0.4f), s.length - 2, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        tvPing.text = sp
        tvPing.setTextColor(
            when {
                ms == null -> DIM
                ms < 60 -> NEON
                ms < 120 -> WARN
                else -> HOT
            }
        )
    }

    private fun tick() {
        if (root == null) return
        val t = TemperatureMonitor(this).read()
        val c = levelColor(t.level)
        tvTemp.text = if (t.batteryC == null) "N/A" else String.format("%.0f °C", t.batteryC)
        tvTemp.setTextColor(c)
        handleBar.background = rounded(c, dp(3).toFloat())
        syncTiles()
        if (!expanded) return
        if (!busy.compareAndSet(false, true)) return
        executor.execute {
            try {
                val monitor = NetworkMonitor(this)
                val net = monitor.status()
                val ping = monitor.pingMs()
                var fps: Int? = null
                val granted = ShizukuHelper.hasPermission()
                if (granted) {
                    val fg = ShellTools.foregroundPackage()
                    val isGame = fg != null && fg != packageName && fg != homePkg &&
                        !fg.startsWith("com.android.systemui")
                    gamePkg = if (isGame) fg else null
                    if (isGame && fg != null) fps = ShellTools.measureFps(fg)
                } else {
                    gamePkg = null
                }
                handler.post {
                    if (root != null) bindStats(net, ping, fps, granted)
                }
            } finally {
                busy.set(false)
            }
        }
    }

    private fun bindStats(net: NetStatus, ping: Int?, fps: Int?, shizuku: Boolean) {
        tvNet.text = when (net.transport) {
            "WLAN" -> buildString {
                append("WLAN")
                if (net.rssiDbm != null) append("  ${net.rssiDbm} dBm")
                if (net.linkMbps != null) append("  ${net.linkMbps} Mbps")
            }
            else -> net.transport
        }
        tvFps.text = if (fps != null) "$fps FPS" else "N/A FPS"
        setPing(ping)
        if (ping != null) {
            pingHistory.add(ping.toFloat())
            if (pingHistory.size > 30) pingHistory.removeAt(0)
        }
        graph.setValues(pingHistory.toList(), NEON)
        tvFooter.text = if (shizuku) {
            "Shizuku: aktif" + (gamePkg?.let { "  •  game: $it" } ?: "")
        } else {
            "Shizuku: belum aktif (FPS game & mode sistem butuh Shizuku) - ketuk untuk atur"
        }
    }

    private fun syncModeButtons() {
        val current = GameSettings(this).profile
        modeButtons.forEach { (p, b) ->
            val sel = p == current
            b.background = if (sel) rounded(Color.argb(60, 0, 183, 255), dp(10).toFloat(), NEON)
            else rounded(Color.TRANSPARENT, dp(10).toFloat())
            b.setTextColor(if (sel) NEON else DIM)
        }
    }

    private fun nm(): NotificationManager = getSystemService(NotificationManager::class.java)

    private fun dndOn(): Boolean {
        val f = nm().currentInterruptionFilter
        return f != NotificationManager.INTERRUPTION_FILTER_ALL &&
            f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    }

    private fun syncTiles() {
        if (root == null) return
        val rec = ScreenRecorderService.isRecording
        blink = !blink
        tileRec.sub.text = if (rec) "Merekam - ketuk untuk berhenti" else "Siap"
        tileRec.dot.background = circle(if (rec) HOT else DIM)
        tileRec.dot.alpha = if (rec && blink) 0.3f else 1f
        val locked = GameSettings(this).frameLock
        tileFrame.sub.text = if (locked) "Refresh rate terkunci" else "Normal"
        tileFrame.dot.background = circle(if (locked) NEON else DIM)
        val dnd = dndOn()
        tileDnd.sub.text = if (dnd) "Aktif" else "Mati"
        tileDnd.dot.background = circle(if (dnd) NEON else DIM)
    }

    private fun refreshFavorites() {
        gamesBox.removeAllViews()
        val launcher = GameLauncher(this)
        val favs = launcher.loadGames(withIcons = false).filter { it.isFavorite }.take(3)
        if (favs.isEmpty()) {
            gamesBox.addView(text("Belum ada favorit (atur di tab Game)", 11f, TEXT).apply { setPadding(dp(4), 0, 0, dp(2)) })
            return
        }
        favs.forEach { g ->
            val b = smallButton(g.label) {
                if (!launcher.launch(g.packageName)) toast("Tidak dapat membuka ${g.label}")
                else if (expanded) toggle()
            }
            gamesBox.addView(b, lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                setMargins(dp(3), dp(3), dp(3), dp(3))
            })
        }
    }

    // ------------------------------------------------------------ aksi

    private fun openApp() {
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        )
    }

    private fun adjustVolume(direction: Int) {
        try {
            (getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                .adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        } catch (e: SecurityException) {
            toast("Tidak dapat mengubah volume.")
        }
    }

    private fun applyBrightness(percent: Int) {
        val gs = GameSettings(this)
        if (gs.canWriteSystemSettings()) {
            gs.setBrightnessPercent(percent)
        } else if (ShizukuHelper.hasPermission()) {
            executor.execute { ShellTools.setBrightness(percent * 255 / 100) }
        } else if (!warnedBrightness) {
            warnedBrightness = true
            toast("Kecerahan butuh izin \"Ubah pengaturan sistem\" atau Shizuku (atur di AISZ > Atur).")
        }
    }

    private fun selectMode(p: GamingProfile) {
        GameSettings(this).profile = p
        syncModeButtons()
        ModeController.applyAsync(this, p, gamePkg) { msg ->
            toast(msg)
            if (root != null) seekBright.progress = GameSettings(this).getBrightnessPercent()
        }
    }

    private fun toggleRecord() {
        if (ScreenRecorderService.isRecording) {
            startService(Intent(this, ScreenRecorderService::class.java).setAction(ScreenRecorderService.ACTION_STOP))
        } else {
            if (expanded) toggle() // sembunyikan panel agar tidak ikut terekam
            startActivity(Intent(this, RecordRequestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun toggleFrameLock() {
        if (!ShizukuHelper.hasPermission()) {
            toast("Frame tinggi butuh Shizuku (atur di AISZ > Atur).")
            return
        }
        val gs = GameSettings(this)
        val target = !gs.frameLock
        executor.execute {
            val r = if (target) ShellTools.lockRefreshRate(ShellTools.maxRefreshRate(this)) else ShellTools.unlockRefreshRate()
            handler.post {
                if (r.ok) {
                    gs.frameLock = target
                    syncTiles()
                    toast(if (target) "Refresh rate dikunci ke maksimum" else "Refresh rate dikembalikan")
                } else {
                    toast("Gagal: ${r.error.ifBlank { r.output }}")
                }
            }
        }
    }

    private fun toggleDnd() {
        if (!nm().isNotificationPolicyAccessGranted) {
            toast("Beri izin akses Jangan Ganggu dulu.")
            try {
                startActivity(
                    Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
            }
            return
        }
        nm().setInterruptionFilter(
            if (dndOn()) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY
        )
        syncTiles()
    }

    private fun quickStart() {
        val launcher = GameLauncher(this)
        executor.execute {
            val games = launcher.loadGames(withIcons = false)
            val g = games.firstOrNull { it.isFavorite } ?: games.firstOrNull()
            if (g == null) {
                handler.post { toast("Belum ada game di daftar.") }
                return@execute
            }
            val msg = ModeController.applyBlocking(this, GamingProfile.PERFORMA, g.packageName)
            val gs = GameSettings(this)
            if (gs.hasDndAccess()) gs.setDnd(true)
            handler.post {
                toast("$msg. Membuka ${g.label}")
                syncModeButtons()
                syncTiles()
                if (expanded) toggle()
                launcher.launch(g.packageName)
            }
        }
    }

    private fun openFloating(pkg: String) {
        if (expanded) toggle()
        executor.execute {
            if (ShizukuHelper.hasPermission()) {
                val r = ShellTools.launchFreeform(this, pkg)
                if (r.ok) return@execute
                handler.post { toast("Jendela mengambang tidak didukung ROM ini, dibuka biasa.") }
            } else {
                handler.post { toast("Jendela mengambang butuh Shizuku, dibuka biasa.") }
            }
            handler.post { GameLauncher(this).launch(pkg) }
        }
    }

    companion object {
        const val ACTION_STOP = "com.aisz.gamespace.action.STOP_PANEL"
        private const val CHANNEL_ID = "aisz_panel"
        private const val NOTIF_ID = 1001

        private val NEON = Color.parseColor("#00B7FF")
        private val TEXT = Color.parseColor("#E6F4FF")
        private val DIM = Color.parseColor("#8AA4BF")
        private val CARD = Color.parseColor("#0E1830")
        private val STROKE = Color.parseColor("#2A4A78")
        private val PANEL_BG = Color.parseColor("#F2060B16")
        private val OK = Color.parseColor("#2BE38B")
        private val WARN = Color.parseColor("#FFB020")
        private val HOT = Color.parseColor("#FF4D5E")

        @Volatile
        var isRunning: Boolean = false
            private set

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, FloatingPanelService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, FloatingPanelService::class.java))
        }
    }
}
