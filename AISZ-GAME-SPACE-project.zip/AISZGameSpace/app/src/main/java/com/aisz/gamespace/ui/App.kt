package com.aisz.gamespace.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aisz.gamespace.MainActivity
import com.aisz.gamespace.TouchTesterScreen

enum class Tab(val label: String, val icon: ImageVector) {
    DASHBOARD("Beranda", Icons.Filled.Home),
    GAMES("Game", Icons.Filled.PlayArrow),
    MONITOR("Monitor", Icons.Filled.Info),
    TOUCH("Sentuh", Icons.Filled.Create),
    SETTINGS("Atur", Icons.Filled.Settings)
}

/** Latar: dua cahaya biru lembut yang bergerak pelan. */
@Composable
private fun AmbientGlow() {
    val t = rememberInfiniteTransition(label = "ambient")
    val p by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse),
        label = "ambientP"
    )
    Canvas(Modifier.fillMaxSize()) {
        val r = size.maxDimension * 0.55f
        val c1 = Offset(size.width * (0.1f + 0.8f * p), size.height * 0.1f)
        val c2 = Offset(size.width * (0.9f - 0.8f * p), size.height * 0.9f)
        drawCircle(
            Brush.radialGradient(listOf(AiszColors.Neon.copy(alpha = 0.20f), Color.Transparent), center = c1, radius = r),
            radius = r, center = c1
        )
        drawCircle(
            Brush.radialGradient(listOf(AiszColors.NeonSoft.copy(alpha = 0.12f), Color.Transparent), center = c2, radius = r),
            radius = r, center = c2
        )
    }
}

@Composable
fun AiszApp(activity: MainActivity) {
    var tab by remember { mutableStateOf(Tab.DASHBOARD) }

    Box(Modifier.fillMaxSize().background(AiszColors.Black)) {
        AmbientGlow()
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                Column {
                    Box(Modifier.fillMaxWidth().height(1.dp).background(AiszColors.Neon.copy(alpha = 0.45f)))
                    NavigationBar(containerColor = AiszColors.Surface) {
                        Tab.values().forEach { t ->
                            NavigationBarItem(
                                selected = tab == t,
                                onClick = { tab = t },
                                icon = { Icon(t.icon, contentDescription = t.label) },
                                label = { Text(t.label, fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = AiszColors.Neon,
                                    selectedTextColor = AiszColors.Neon,
                                    unselectedIconColor = AiszColors.TextDim,
                                    unselectedTextColor = AiszColors.TextDim,
                                    indicatorColor = AiszColors.Neon.copy(alpha = 0.2f)
                                )
                            )
                        }
                    }
                }
            }
        ) { padding ->
            AnimatedContent(
                targetState = tab,
                modifier = Modifier.padding(padding),
                transitionSpec = { fadeIn(tween(280)) togetherWith fadeOut(tween(160)) },
                label = "tab"
            ) { current ->
                when (current) {
                    Tab.DASHBOARD -> DashboardScreen(activity) { tab = it }
                    Tab.GAMES -> GamesScreen(activity)
                    Tab.MONITOR -> MonitorScreen()
                    Tab.TOUCH -> TouchTesterScreen()
                    Tab.SETTINGS -> SettingsScreen(activity)
                }
            }
        }
    }
}
